import { type Diagnostics } from "./diagnostics";
import type { Series } from "../model/types";
export type ValidateSeriesOptions = {
    /**
     * If true, empty series are treated as errors.
     * MVP default: warn, because dashboards sometimes load async.
     */
    strictNonEmpty?: boolean;
    /**
     * If true, we warn when x values are not monotonic (time-series expectation).
     * Not all charts need monotonic x, but it helps users catch surprises.
     */
    warnIfXNotSorted?: boolean;
};
/**
 * Validate multi-series time-series input for line/area charts.
 *
 * Notes:
 * - We do not "fix" data here (no sorting, no filtering). That belongs to app or transforms.
 * - We only detect common pitfalls and return actionable diagnostics.
 */
export declare function validateSeriesInput(series: Series[], options?: ValidateSeriesOptions): Diagnostics;
//# sourceMappingURL=validateSeries.d.ts.map