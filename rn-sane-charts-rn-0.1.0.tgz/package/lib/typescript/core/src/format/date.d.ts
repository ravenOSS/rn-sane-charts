export declare function formatDateDefault(d: Date): string;
/**
 * Build a date formatter tuned to the visible domain span.
 *
 * Why:
 * - Tick generation currently operates on numeric milliseconds which can yield
 *   non-midnight Date values for multi-day domains.
 * - Using a domain-aware formatter prevents "clock time" labels on charts that
 *   conceptually represent days/weeks/months.
 *
 * Rules (MVP):
 * - >= 365 days: show year
 * - >= 60 days: show month/year
 * - >= 2 days: show day
 * - otherwise: show clock time
 */
export declare function makeDomainDateFormatter(domain: [Date, Date]): any;
//# sourceMappingURL=date.d.ts.map