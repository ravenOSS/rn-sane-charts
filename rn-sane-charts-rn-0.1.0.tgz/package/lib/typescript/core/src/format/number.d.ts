/**
 * Default numeric formatter.
 *
 * Philosophy:
 * - Business charts should avoid noise.
 * - This formatter tries to produce compact, human-readable labels.
 *
 * Future extension:
 * - Locale-aware formatting
 * - Currency/percent helpers
 */
export declare function formatNumberDefault(value: number): string;
//# sourceMappingURL=number.d.ts.map