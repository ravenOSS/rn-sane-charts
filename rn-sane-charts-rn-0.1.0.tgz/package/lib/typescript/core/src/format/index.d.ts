export * from "./date";
export * from "./number";
//# sourceMappingURL=index.d.ts.map