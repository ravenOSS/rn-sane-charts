export type XYPoint = {
    x: number;
    y: number;
};
/**
 * Nearest-neighbor hit test in 2D screen space.
 *
 * Why this helper lives in core:
 * - It is pure geometry math with no renderer dependencies.
 * - Keeping this in core makes interaction behavior deterministic and testable.
 */
export declare function findNearestPoint<T extends XYPoint>(points: readonly T[], x: number, y: number): T | null;
/**
 * Collect points aligned to a shared x-anchor.
 *
 * Use case:
 * - "index" interaction mode groups all series at the nearest x-slot.
 */
export declare function collectPointsAtAnchorX<T extends XYPoint>(points: readonly T[], anchorX: number, tolerancePx?: number): T[];
//# sourceMappingURL=hitTestLine.d.ts.map