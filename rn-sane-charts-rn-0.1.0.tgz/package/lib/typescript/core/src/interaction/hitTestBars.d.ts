export type RectLike = {
    x: number;
    y: number;
    width: number;
    height: number;
};
/**
 * Inclusive point-in-rect check in screen space.
 *
 * Used by bar/legend/tool overlays to resolve tap targets deterministically.
 */
export declare function isPointInRect(x: number, y: number, rect: RectLike): boolean;
//# sourceMappingURL=hitTestBars.d.ts.map