import type { XYPoint } from "./hitTestLine";
/**
 * Find the nearest numeric value in a sorted or unsorted array.
 *
 * Why this helper exists:
 * - Gesture interaction often needs nearest x-slot snapping.
 * - Keeping it pure allows consistent snapping behavior across renderers.
 */
export declare function findNearestNumericValue(values: readonly number[], target: number): number;
export type ScatterSpatialIndex<T extends XYPoint> = {
    cellSizePx: number;
    buckets: Map<string, T[]>;
    minCellX: number;
    maxCellX: number;
    minCellY: number;
    maxCellY: number;
};
/**
 * Build a deterministic spatial hash for 2D points.
 *
 * Why this helper exists:
 * - Scatter interactions are nearest-neighbor queries on every gesture move.
 * - A cell index keeps lookup local to nearby buckets instead of scanning all
 *   points, which stabilizes interaction cost for larger datasets.
 *
 * Invariants:
 * - Input order is preserved inside each bucket.
 * - Non-finite points are skipped.
 * - `cellSizePx` is clamped to a safe positive default.
 */
export declare function buildScatterSpatialIndex<T extends XYPoint>(points: readonly T[], cellSizePx?: number): ScatterSpatialIndex<T>;
/**
 * Query nearest point via scatter spatial index.
 *
 * Search strategy:
 * 1. Expand cell rings around query cell.
 * 2. Track best point distance found so far.
 * 3. Stop when the theoretical nearest point outside scanned rings cannot beat
 *    the current best distance.
 *
 * This yields exact nearest-neighbor results while avoiding full-array scans.
 */
export declare function findNearestPointInScatterIndex<T extends XYPoint>(index: ScatterSpatialIndex<T>, x: number, y: number): T | null;
//# sourceMappingURL=hitTestScatter.d.ts.map