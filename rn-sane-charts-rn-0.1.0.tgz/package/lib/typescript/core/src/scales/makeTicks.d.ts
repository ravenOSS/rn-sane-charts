import type { Tick, YTick } from "../model/types";
/**
 * Generate y-axis ticks for a linear scale.
 *
 * Core outputs ticks with pixel positions. This keeps layout deterministic.
 */
export declare function makeYTicks(input: {
    yDomain: [number, number];
    yScale: (v: number) => number;
    count?: number;
    formatY?: (v: number) => string;
}): YTick[];
/**
 * Generate x-axis ticks for a time scale.
 *
 * MVP behavior:
 * - Use a fixed tick count heuristic.
 * - Format with a simple default date formatter.
 *
 * Important:
 * - Collision resolution happens later in layout.
 * - This function should NOT attempt rotation/skip logic.
 */
export declare function makeTimeXTicks(input: {
    xDomain: [Date, Date];
    xScale: (v: Date) => number;
    count?: number;
    formatX?: (d: Date) => string;
}): Tick[];
/**
 * Generate x-axis ticks at explicit Date values.
 *
 * Why:
 * - Category-like charts often project labels onto synthetic time slots.
 * - Auto-generated domain ticks can drift from those slots, causing labels
 *   to appear missing or misaligned under bars/groups.
 *
 * This function guarantees one tick candidate per provided value (after
 * dedupe/sort), then collision logic may still skip some for readability.
 */
export declare function makeTimeXTicksFromValues(input: {
    values: Date[];
    xScale: (v: Date) => number;
    formatX?: (d: Date) => string;
    xDomain?: [Date, Date];
}): Tick[];
//# sourceMappingURL=makeTicks.d.ts.map