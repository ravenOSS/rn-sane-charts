import type { PixelRange, InvertibleScaleFn } from "./scaleTypes";
/**
 * Create a time scale mapping Date domain to pixel range.
 *
 * We use Date objects at the public boundary for clarity.
 */
export declare function createTimeScale(domain: [Date, Date], range: PixelRange): InvertibleScaleFn<Date>;
//# sourceMappingURL=time.d.ts.map