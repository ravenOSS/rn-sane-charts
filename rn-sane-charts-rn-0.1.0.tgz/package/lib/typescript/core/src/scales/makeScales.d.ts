import type { DomainNumber, DomainDate } from "../model/types";
import type { Rect } from "../layout/computeLayout";
/**
 * Scale bundle for the common "time-series line/area" chart.
 *
 * We define these as factories so:
 * - geometry and interaction code can rely on consistent conventions
 * - renderer packages don't need to understand d3
 */
export declare function makeTimeSeriesScales(input: {
    plot: Rect;
    xDomain: DomainDate;
    yDomain: DomainNumber;
}): {
    x: import("./scaleTypes").InvertibleScaleFn<Date>;
    y: import("./scaleTypes").InvertibleScaleFn<number>;
};
//# sourceMappingURL=makeScales.d.ts.map