import type { Domain, PixelRange, InvertibleScaleFn } from "./scaleTypes";
/**
 * Create a linear scale mapping a numeric domain to a pixel range.
 *
 * Notes:
 * - This is a thin wrapper around d3-scale to keep d3 usage contained.
 * - The returned function is invertible (px → value), which is useful for tooltips.
 */
export declare function createLinearScale(domain: Domain, range: PixelRange): InvertibleScaleFn<number>;
//# sourceMappingURL=linear.d.ts.map