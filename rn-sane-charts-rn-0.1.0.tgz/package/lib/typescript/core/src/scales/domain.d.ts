import type { DomainNumber, DomainDate, Series } from "../model/types";
/**
 * Compute numeric y-domain across all series.
 *
 * Important:
 * - Returns [min, max] including 0 if includeZero is true (bar chart default).
 * - If data is empty or invalid, returns a safe default.
 */
export declare function computeYDomain(series: Series[], opts?: {
    includeZero?: boolean;
}): DomainNumber;
/**
 * Compute x-domain for time-series.
 *
 * Assumes x is Date or number. For Date, uses min/max by time.
 */
export declare function computeXDomainTime(series: Series[]): DomainDate;
//# sourceMappingURL=domain.d.ts.map