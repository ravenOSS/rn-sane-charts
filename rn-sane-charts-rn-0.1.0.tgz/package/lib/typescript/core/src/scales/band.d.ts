import type { PixelRange, ScaleFn } from "./scaleTypes";
/**
 * Create a band scale for categorical axes.
 *
 * This is commonly used for bar charts.
 */
export declare function createBandScale(domain: Array<string | number>, range: PixelRange, paddingInner?: number): {
    scale: ScaleFn<string | number>;
    bandwidth: () => any;
    /** Center of band is useful for label positioning. */
    center: (v: string | number) => any;
};
//# sourceMappingURL=band.d.ts.map