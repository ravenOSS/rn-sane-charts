export { resolveXAxisLabels } from "./resolveXAxisLabels";
export type { ResolveXAxisLabelsConfig, ResolvedXAxisLabels, BoundingBox } from "./resolveXAxisLabels";
//# sourceMappingURL=index.d.ts.map