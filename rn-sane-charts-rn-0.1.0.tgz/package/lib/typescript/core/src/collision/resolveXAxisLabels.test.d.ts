export {};
//# sourceMappingURL=resolveXAxisLabels.test.d.ts.map