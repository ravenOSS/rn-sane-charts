import type { Degrees, MeasureTextFn, FontSpec } from "../layout/measureTextTypes";
/**
 * Bounding box in pixel space for collision detection.
 *
 * Coordinate system:
 * - X increases to the right.
 * - Y increases downward.
 *
 * For x-axis labels, we care primarily about xMin/xMax overlap.
 */
export type BoundingBox = {
    xMin: number;
    xMax: number;
    yMin: number;
    yMax: number;
};
export type Tick = {
    /** Original scale value (Date, number, category). */
    value: unknown;
    /** Formatted string label to render. */
    label: string;
    /** Pixel position of the tick on the axis (center point for label). */
    x: number;
};
export type ResolveXAxisLabelsConfig = {
    /**
     * Font used for tick labels. Must match renderer to avoid clipping/collisions.
     */
    font: FontSpec;
    /**
     * Angles to try, in order.
     *
     * Default is intentionally conservative and familiar:
     * - 0° keeps labels horizontal
     * - 45° solves many collisions while preserving readability
     * - 90° is a last resort for dense categorical axes
     *
     * We keep this as a *config* (not a public prop in MVP) so we can evolve
     * behavior without breaking API.
     */
    anglesToTry?: Degrees[];
    /**
     * Minimum gap (px) required between adjacent labels to be considered non-colliding.
     * A few pixels helps avoid "touching" labels which still feels cluttered.
     */
    minLabelGapPx?: number;
    /**
     * If true, rotation is attempted before skipping ticks.
     * This generally looks better for business charts.
     */
    preferRotationOverSkipping?: boolean;
    /**
     * Hard cap on skipping to prevent pathological loops.
     * If we exceed this, we fall back to first/last tick only.
     */
    maxSkipStep?: number;
};
export type ResolvedXAxisLabels = {
    /**
     * Chosen angle that produced collision-free layout (or best-effort fallback).
     */
    angle: Degrees;
    /**
     * The final set of ticks to render (may be filtered by skipping).
     */
    ticks: Tick[];
    /**
     * Bounding boxes for the final ticks; used for:
     * - layout bottom margin calculation
     * - debugging/visual test harnesses
     */
    labelBoxes: BoundingBox[];
    /**
     * Required vertical space (px) under the plot area to render tick labels safely.
     * This is derived from measured label height AFTER rotation.
     */
    requiredBottomMarginPx: number;
    /**
     * Optional debug info for developers (can be stripped/minimized later).
     */
    debug?: {
        attemptedAngles: Degrees[];
        attemptedSkipSteps: number[];
        reason: "no-collision" | "skip-resolved" | "fallback-first-last";
    };
};
/**
 * Resolve x-axis label collisions using rotation and/or tick skipping.
 *
 * Strategy (intentionally human-friendly):
 * 1) Try rotation-only: 0°, then 45°, then 90°
 * 2) If still colliding, apply tick skipping and re-try angles
 * 3) If nothing works, fall back to showing only first+last ticks at 90°
 *
 * Why this strategy:
 * - Rotation preserves data density better than skipping for many time-series axes.
 * - 45° is a common readability compromise and often "just works".
 * - Skipping is necessary for very dense categorical axes.
 * - First/last fallback guarantees something readable in all cases.
 *
 * Future extension points:
 * - Add 60° (useful when 45° still collides but 90° is too extreme)
 * - Smarter tick selection (e.g., always include last, include month boundaries)
 * - Multi-line labels (wrapping) for categories
 */
export declare function resolveXAxisLabels(inputTicks: Tick[], measureText: MeasureTextFn, config: ResolveXAxisLabelsConfig): ResolvedXAxisLabels;
//# sourceMappingURL=resolveXAxisLabels.d.ts.map