import type { AreaPath, Series } from "../model/types";
import type { StackedSeries } from "../transforms/stack";
/**
 * Build an SVG-style closed path string for an area series.
 *
 * Why this API exists:
 * - Area charts are a direct geometric extension of line charts.
 * - Core returns renderer-agnostic SVG path strings so RN/Skia can consume
 *   them directly while keeping chart math deterministic and testable.
 *
 * Geometry strategy:
 * - Use monotone interpolation on the upper curve (business-chart default).
 * - Trace back on a constant baseline and close the polygon.
 * - Skip non-finite data points; D3 will break/restart segments automatically.
 *
 * Invariants:
 * - Returned path is closed (`...Z`) when at least one valid segment exists.
 * - Default baseline is `0`, matching common area-chart conventions.
 */
export declare function buildAreaPath(series: Series, scales: {
    x: (v: any) => number;
    y: (v: number) => number;
}, opts?: {
    baselineY?: number;
}): AreaPath;
/**
 * Build an SVG path for a stacked-area band (`y0` -> `y1`) series.
 *
 * Why this helper exists:
 * - Stacked areas need per-point lower and upper boundaries, not a single
 *   constant baseline.
 * - Keeping this geometry in core lets RN/Web renderers share identical math.
 */
export declare function buildStackedAreaPath(series: StackedSeries, scales: {
    x: (v: any) => number;
    y: (v: number) => number;
}): AreaPath;
//# sourceMappingURL=areaPath.d.ts.map