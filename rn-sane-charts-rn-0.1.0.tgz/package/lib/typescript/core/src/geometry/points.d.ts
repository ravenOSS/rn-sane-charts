import type { Point, Series } from "../model/types";
/**
 * Convert a series into pixel-space points.
 * Used for:
 * - scatter plots
 * - markers
 * - hit-testing indices
 */
export declare function buildPoints(series: Series, scales: {
    x: (v: any) => number;
    y: (v: number) => number;
}): Point[];
//# sourceMappingURL=points.d.ts.map