export {};
//# sourceMappingURL=areaPath.test.d.ts.map