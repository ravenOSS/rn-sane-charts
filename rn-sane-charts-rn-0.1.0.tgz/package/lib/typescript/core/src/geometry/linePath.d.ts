import type { LinePath, Series } from "../model/types";
/**
 * Build an SVG-style path string for a line series.
 *
 * Why SVG path strings in core:
 * - Skia can ingest SVG path strings.
 * - Keeps geometry renderer-agnostic.
 * - Easy to snapshot-test (goldens can compare path output).
 *
 * Notes:
 * - We skip non-finite points (breaks the line).
 * - Curve choice is monotone by default, which is a good business-chart default.
 */
export declare function buildLinePath(series: Series, scales: {
    x: (v: any) => number;
    y: (v: number) => number;
}): LinePath;
//# sourceMappingURL=linePath.d.ts.map