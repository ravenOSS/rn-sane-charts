import type { Series, XValue } from "../model/types";
export type StackedPoint = {
    x: XValue;
    y: number;
    y0: number;
    y1: number;
};
export type StackedSeries = {
    id: string;
    data: StackedPoint[];
};
/**
 * Build stacked y extents (`y0`/`y1`) for aligned multi-series data.
 *
 * Why this exists:
 * - Core needs a renderer-agnostic stacking transform for stacked bars and
 *   stacked area so both chart types share consistent math.
 * - Keeping stacking in core makes totals/domains deterministic and testable.
 *
 * Behavior:
 * - Alignment is by x-value across all input series.
 * - Missing values are treated as `0`.
 * - Positive and negative values stack independently around baseline `0`.
 * - Output preserves input series order and sorted x domain order.
 */
export declare function stackSeries(series: readonly Series[]): StackedSeries[];
//# sourceMappingURL=stack.d.ts.map