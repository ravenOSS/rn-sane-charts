/**
 * Histogram binning for MVP.
 *
 * Why this is in core:
 * - Binning is deterministic math and easy to test.
 * - Renderer should only draw bars after binning is done.
 *
 * MVP behavior:
 * - If binCount is provided, use it.
 * - Otherwise choose a simple heuristic: sqrt(n) (common default).
 * - Returns bins with [x0, x1) ranges and count.
 *
 * Future extension:
 * - Scott's rule / Freedman–Diaconis rule
 * - Handling outliers / clamping domain
 */
export type HistogramBin = {
    x0: number;
    x1: number;
    count: number;
};
export declare function binHistogram(values: number[], opts?: {
    binCount?: number;
    domain?: [number, number];
}): HistogramBin[];
//# sourceMappingURL=binHistogram.d.ts.map