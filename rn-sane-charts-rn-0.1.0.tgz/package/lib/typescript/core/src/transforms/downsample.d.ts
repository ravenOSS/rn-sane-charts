import type { Series } from "../model/types";
/**
 * Reduce point count while preserving trend shape for dense series.
 *
 * Why this transform exists:
 * - Rendering every point at high density can waste work without visual gain.
 * - A deterministic core transform lets renderers share the same sampling logic.
 *
 * Strategy:
 * - Preserve first and last points.
 * - Split interior points into buckets.
 * - Keep bucket min/max y points (in original order) to preserve spikes.
 *
 * Notes:
 * - This is not an LTTB implementation; it is an intentionally simple and
 *   predictable min/max sampler suitable for MVP.
 */
export declare function downsampleSeries(series: Series, options: {
    maxPoints: number;
}): Series;
//# sourceMappingURL=downsample.d.ts.map