export {};
//# sourceMappingURL=legend.test.d.ts.map