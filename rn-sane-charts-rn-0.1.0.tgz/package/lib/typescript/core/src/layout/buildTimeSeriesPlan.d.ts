import type { Series } from "../model/types";
import type { LayoutInput } from "./computeLayout";
/**
 * Build a minimal "plan" for a time-series chart:
 * - validate
 * - domains
 * - scales (needs plot, but plot needs layout... so we do a two-pass approach)
 *
 * Two-pass approach rationale:
 * - Layout needs ticks (for collisions) and tick labels need scales.
 * - Scales need plot rect.
 *
 * MVP simplification:
 * - Pass 1: assume plot = full chart minus padding/header (rough)
 * - Compute ticks
 * - Layout resolves collisions and returns final plot rect
 * - Pass 2: rebuild scales/ticks with final plot
 *
 * This keeps the system deterministic and avoids circular dependencies.
 * Future refinement can unify this into a single iterative solver if needed.
 */
export declare function buildTimeSeriesPlan(args: {
    series: Series[];
    layoutInput: Omit<LayoutInput, "xTicks" | "yTicks">;
    yIncludeZero?: boolean;
    tickCounts?: {
        x?: number;
        y?: number;
    };
    xTickValues?: Date[];
    xTickDomainMode?: "slots" | "exact";
    formatX?: (d: Date) => string;
    formatY?: (v: number) => string;
}): {
    diagnostics: import("..").Diagnostics;
    domains: {
        x: import("..").DomainDate;
        y: import("..").DomainNumber;
    };
    scales: {
        x: import("..").InvertibleScaleFn<Date>;
        y: import("..").InvertibleScaleFn<number>;
    };
    ticks: {
        x: import("..").Tick[];
        y: import("..").YTick[];
    };
    layout: import("./computeLayout").LayoutOutput;
};
//# sourceMappingURL=buildTimeSeriesPlan.d.ts.map