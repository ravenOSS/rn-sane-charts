import type { ChartPadding, Tick, YTick } from "../model/types";
import type { MeasureTextFn } from "./measureTextTypes";
import type { AxisSpec, ChartTextSpec, LayoutResult } from "./layoutTypes";
export type { AxisSpec, ChartTextSpec, LayoutResult, Rect } from "./layoutTypes";
export type LayoutInput = {
    width: number;
    height: number;
    padding?: ChartPadding;
    text: ChartTextSpec;
    xAxis: AxisSpec;
    yAxis: AxisSpec;
    /**
     * Renderer-provided text measurement function.
     *
     * Contract: returns AABB width/height AFTER rotation.
     */
    measureText: MeasureTextFn;
    /** Precomputed ticks with pixel positions. */
    xTicks: Tick[];
    yTicks: YTick[];
};
export type LayoutOutput = LayoutResult & {
    /**
     * Full x-axis label resolution result.
     *
     * Core returns this so the renderer can follow the same decisions (angle + skipping),
     * and so subsequent planning passes can reuse the computed tick list.
     */
    resolvedXAxis: {
        angle: number;
        ticks: Tick[];
        requiredBottomMarginPx: number;
    };
};
/**
 * Compute chart layout rectangles (header / plot / axes) and x-axis label decisions.
 *
 * Design goals:
 * - Deterministic: depends only on inputs (ticks are already in pixel space)
 * - Conservative: avoids clipped labels by budgeting margins from measured text
 * - Minimal: enough for MVP charts; can be refined iteratively
 *
 * Strategy (MVP):
 * - Measure header height from title/subtitle
 * - Measure y-axis width from the widest y tick label
 * - Resolve x-axis collisions (angle + skipping) to derive required bottom margin
 * - Allocate plot rect from remaining space, respecting padding
 */
export declare function computeLayout(input: LayoutInput): LayoutOutput;
//# sourceMappingURL=computeLayout.d.ts.map