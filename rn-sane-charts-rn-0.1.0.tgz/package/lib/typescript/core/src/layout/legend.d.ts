import type { FontSpec, MeasureTextFn } from "./measureTextTypes";
import type { LayoutResult } from "./layoutTypes";
export type LegendPositionPreference = "auto" | "right" | "bottom";
export type LegendPosition = "right" | "bottom";
export type LegendOrientation = "vertical" | "horizontal";
export type LegendItem = {
    id: string;
    label: string;
    color: string;
};
export type LegendMeasuredItem = LegendItem & {
    textWidth: number;
    textHeight: number;
    rowWidth: number;
};
export type LegendSizingOptions = {
    swatchSizePx?: number;
    swatchTextGapPx?: number;
    itemGapPx?: number;
    paddingPx?: number;
    outerMarginPx?: number;
    rightReserveGapPx?: number;
    bottomReserveGapPx?: number;
    rightPlacementMinChartWidthPx?: number;
    rightPlacementMaxWidthRatio?: number;
};
export type LegendLayoutResult = {
    show: boolean;
    items: LegendMeasuredItem[];
    position: LegendPosition;
    orientation: LegendOrientation;
    width: number;
    height: number;
    rowHeight: number;
    reservedRight: number;
    reservedBottom: number;
    metrics: Required<LegendSizingOptions>;
};
export type LegendItemBox = {
    id: string;
    x: number;
    y: number;
    width: number;
    height: number;
};
/**
 * Resolve legend placement/orientation and reserved chart padding.
 *
 * Why this belongs in core:
 * - Placement is layout policy, not renderer behavior.
 * - Keeping it pure makes "legend never covers plot" testable and deterministic.
 */
export declare function computeLegendLayout(input: {
    chartWidth: number;
    items: LegendItem[];
    measureText: MeasureTextFn;
    font: FontSpec;
    show?: boolean;
    position?: LegendPositionPreference;
    metrics?: LegendSizingOptions;
}): LegendLayoutResult;
/**
 * Compute per-item hit boxes using resolved legend layout.
 *
 * Why this is core logic:
 * - Hit regions depend on deterministic layout geometry and policy constants.
 * - Keeping this function pure allows renderer and tests to share exact behavior.
 */
export declare function computeLegendItemBoxes(input: {
    chartWidth: number;
    chartHeight: number;
    layout: LayoutResult;
    legend: Pick<LegendLayoutResult, "show" | "items" | "position" | "orientation" | "width" | "height" | "rowHeight" | "metrics">;
}): LegendItemBox[];
export declare function findLegendHit(boxes: readonly LegendItemBox[], x: number, y: number): LegendItemBox | null;
//# sourceMappingURL=legend.d.ts.map