import type { SaneChartTheme } from '../types';
/**
 * Light preset used as the baseline chart look.
 */
export declare const lightTheme: SaneChartTheme;
/**
 * Dark preset tuned for contrast on non-black surfaces.
 */
export declare const darkTheme: SaneChartTheme;
/**
 * Backward-compatible alias for existing imports.
 */
export declare const defaultTheme: SaneChartTheme;
//# sourceMappingURL=defaultTheme.d.ts.map