/**
 * Temporary example helper exported by the template.
 *
 * This keeps the RN package's example app compiling while the chart gallery is
 * being built out. Once the example renders actual charts, we can remove this.
 */
export declare function multiply(a: number, b: number): number;
//# sourceMappingURL=multiply.d.ts.map