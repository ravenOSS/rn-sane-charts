import React from 'react';
import type { Series } from '@rn-sane-charts/core';
import type { ChartColorScheme, ChartInteraction, LegendInteractionMode, SaneChartFonts, SaneChartTheme } from './types';
export type ChartProps = {
    width: number;
    height: number;
    series: Series[];
    title?: string;
    subtitle?: string;
    xAxisTitle?: string;
    yAxisTitle?: string;
    yIncludeZero?: boolean;
    formatX?: (d: Date) => string;
    formatY?: (v: number) => string;
    tickCounts?: {
        x?: number;
        y?: number;
    };
    xTickValues?: Date[];
    xTickDomainMode?: 'slots' | 'exact';
    legend?: {
        show?: boolean;
        position?: 'auto' | 'right' | 'bottom';
        interactive?: boolean;
        interactionMode?: LegendInteractionMode;
        items?: Array<{
            id: string;
            label?: string;
            color?: string;
        }>;
    };
    annotations?: {
        markers?: Array<{
            id?: string;
            x: number | Date;
            y: number;
            label?: string;
            color?: string;
            size?: number;
        }>;
    };
    fonts: SaneChartFonts;
    colorScheme?: ChartColorScheme;
    interaction?: ChartInteraction;
    theme?: Partial<SaneChartTheme>;
    /** Children are series components, axes, etc. */
    children: React.ReactNode;
};
/**
 * Chart root component.
 *
 * Responsibilities:
 * - Runs core planning (validation, domains, scales, ticks, layout decisions)
 * - Hosts the Skia canvas and plot clipping
 * - Provides `ChartContext` for series renderers (scales/layout/theme/fonts)
 *
 * Non-goals (MVP):
 * - Web renderer
 * - Pluggable composition systems
 */
export declare function Chart(props: ChartProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Chart.d.ts.map