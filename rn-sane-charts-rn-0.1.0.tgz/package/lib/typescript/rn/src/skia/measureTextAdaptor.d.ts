import type { SkFont } from '@shopify/react-native-skia';
import type { MeasureTextFn } from '@rn-sane-charts/core';
/**
 * Create a core-compatible `measureText` function using Skia text metrics.
 *
 * Core requirement:
 * - Return axis-aligned bounding box (AABB) width/height AFTER rotation.
 * - Respect the `FontSpec` provided on each `TextMeasureInput`.
 *
 * Why this adapter resolves fonts per call:
 * - Core layout can measure x ticks, y ticks, title, and subtitle with different
 *   font sizes/weights.
 * - If we always measured with one fixed SkFont, header centering and margin
 *   calculations drift from what is actually rendered.
 *
 * Performance:
 * - Font resolution uses a small cache keyed by normalized `FontSpec`, so
 *   repeated axis/tick measurements do not re-run `matchFont`.
 *
 * Rotation math:
 * - Compute rotated AABB dimensions from the unrotated width/height using trig.
 * - This is conservative (collision-safe) and fast.
 */
export declare function makeSkiaMeasureText(fallbackFont?: SkFont): MeasureTextFn;
//# sourceMappingURL=measureTextAdaptor.d.ts.map