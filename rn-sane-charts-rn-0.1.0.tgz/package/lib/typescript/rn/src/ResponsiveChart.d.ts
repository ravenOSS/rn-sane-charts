import type { StyleProp, ViewStyle } from 'react-native';
import { type ChartProps } from './Chart';
export type ResponsiveChartProps = Omit<ChartProps, 'width' | 'height'> & {
    /**
     * Optional explicit width override.
     *
     * When omitted, the wrapper measures the parent width via `onLayout`.
     */
    width?: number;
    /**
     * Optional explicit height override.
     *
     * When omitted, height is derived from width / `aspectRatio`.
     */
    height?: number;
    /**
     * Width / height ratio used to derive responsive height.
     *
     * Example: 1.6 means width 320 => height 200.
     */
    aspectRatio?: number;
    /** Lower clamp for computed responsive height. */
    minHeight?: number;
    /** Upper clamp for computed responsive height. */
    maxHeight?: number;
    /** Style for the outer measuring container. */
    containerStyle?: StyleProp<ViewStyle>;
};
/**
 * Responsive wrapper around `Chart`.
 *
 * Why this component exists:
 * - `Chart` is intentionally low-level and deterministic: it expects concrete
 *   pixel bounds for width/height.
 * - App screens usually need charts that adapt to available width while
 *   preserving a stable aspect ratio.
 *
 * Sizing precedence:
 * 1. Explicit `width` / `height` props
 * 2. Measured parent width + derived height from `aspectRatio`
 * 3. Height clamps (`minHeight`, `maxHeight`)
 */
export declare function ResponsiveChart(props: ResponsiveChartProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ResponsiveChart.d.ts.map