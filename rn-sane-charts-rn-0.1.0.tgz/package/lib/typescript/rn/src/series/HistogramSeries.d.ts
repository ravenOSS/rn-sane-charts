type HistogramDrawableBin = {
    x0: number | Date;
    x1: number | Date;
    count: number;
};
export type HistogramSeriesProps = {
    bins: HistogramDrawableBin[];
    color?: string;
    opacity?: number;
    gapPx?: number;
    baselineY?: number;
};
/**
 * Draw histogram bars from precomputed bins.
 *
 * Why bins are an explicit input:
 * - Binning policy is domain math and belongs in core/app transforms.
 * - Renderer should focus on deterministic drawing from already-shaped data.
 */
export declare function HistogramSeries(props: HistogramSeriesProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=HistogramSeries.d.ts.map