import type { Series } from "@rn-sane-charts/core";
export type StackedAreaSeriesProps = {
    series: Series[];
    colors?: readonly string[];
    fillOpacity?: number;
    strokeWidth?: number;
};
/**
 * Draw stacked area layers from aligned multi-series data.
 *
 * Why this component exists:
 * - Completes the MVP "area (including stacked)" feature.
 * - Reuses core stacking + geometry helpers so renderer logic stays thin and
 *   deterministic.
 */
export declare function StackedAreaSeries(props: StackedAreaSeriesProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=StackedAreaSeries.d.ts.map