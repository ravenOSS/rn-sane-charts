import type { Series } from '@rn-sane-charts/core';
import { type MarkerSymbol } from './markerSymbol';
export type ScatterSeriesProps = {
    series: Series;
    color?: string;
    symbol?: MarkerSymbol;
    size?: number;
    strokeWidth?: number;
    filled?: boolean;
    opacity?: number;
    hitRadiusPx?: number;
};
/**
 * Draw a scatter series from core point geometry.
 *
 * Why we delegate point building to core:
 * - Keeps scale projection deterministic and testable.
 * - Reuses shared geometry path used by hit-testing/interaction layers.
 */
export declare function ScatterSeries(props: ScatterSeriesProps): import("react/jsx-runtime").JSX.Element | null;
//# sourceMappingURL=ScatterSeries.d.ts.map