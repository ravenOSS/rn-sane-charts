import type { Series } from '@rn-sane-charts/core';
/**
 * Compute a reasonable bar slot width from x positions.
 *
 * Strategy:
 * - Measure nearest-neighbor spacing between sorted x positions.
 * - Use the tightest gap as the slot width baseline.
 * - Fall back to a conservative constant for sparse/degenerate inputs.
 */
export declare function computeBarSlotWidthPx(seriesList: Series[], xScale: (v: any) => number): number;
export declare function resolveBaselineYPx(yScale: (v: number) => number, baselineY?: number): number;
//# sourceMappingURL=barGeometry.d.ts.map