import type { Series } from '@rn-sane-charts/core';
export type GroupedBarSeriesProps = {
    series: Series[];
    colors?: readonly string[];
    opacity?: number;
    groupWidthRatio?: number;
    baselineY?: number;
};
/**
 * Draw grouped bars for multiple series sharing the same x slots.
 *
 * Assumption:
 * - Series are aligned by datum index (same x positions in each series).
 * - Missing points are skipped safely.
 */
export declare function GroupedBarSeries(props: GroupedBarSeriesProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=GroupedBarSeries.d.ts.map