import type { Series } from '@rn-sane-charts/core';
import { type MarkerStyle } from './markerSymbol';
export type AreaSeriesProps = {
    series: Series;
    fillColor?: string;
    fillOpacity?: number;
    strokeColor?: string;
    strokeWidth?: number;
    baselineY?: number;
    marker?: Omit<MarkerStyle, 'color'> & {
        color?: string;
    };
};
/**
 * Draw a single filled area series inside the plot region.
 *
 * Why this shape:
 * - Keeps area chart API parallel with `LineSeries` while exposing a small set
 *   of fill/stroke controls needed in business dashboards.
 * - Baseline defaults to `0` but can be overridden for specialized displays.
 */
export declare function AreaSeries(props: AreaSeriesProps): import("react/jsx-runtime").JSX.Element | null;
//# sourceMappingURL=AreaSeries.d.ts.map