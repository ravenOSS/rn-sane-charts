import type { Series } from '@rn-sane-charts/core';
export type StackedBarSeriesProps = {
    series: Series[];
    colors?: readonly string[];
    opacity?: number;
    widthRatio?: number;
    baselineY?: number;
};
/**
 * Draw stacked bars from multiple aligned series.
 *
 * Why this implementation:
 * - Stacking math belongs in core so stacked bars and stacked area share the
 *   same deterministic transform and domain behavior.
 * - RN is responsible only for projection and drawing decisions.
 *
 * Behavior:
 * - Positive values stack upward from baseline; negative values stack downward.
 * - Alignment is by x-value via `stackSeries` (not by local array index).
 * - `baselineY` offsets the rendered stack without changing the core transform.
 */
export declare function StackedBarSeries(props: StackedBarSeriesProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=StackedBarSeries.d.ts.map