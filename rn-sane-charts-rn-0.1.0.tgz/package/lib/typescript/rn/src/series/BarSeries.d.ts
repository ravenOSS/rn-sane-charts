import type { Series } from '@rn-sane-charts/core';
export type BarSeriesProps = {
    series: Series;
    color?: string;
    opacity?: number;
    widthRatio?: number;
    baselineY?: number;
};
/**
 * Draw a single bar series against the chart x/y scales.
 *
 * Width heuristic:
 * - We infer slot width from neighboring x positions and apply `widthRatio`.
 * - This keeps bars legible across dense and sparse domains without extra props.
 */
export declare function BarSeries(props: BarSeriesProps): import("react/jsx-runtime").JSX.Element | null;
//# sourceMappingURL=BarSeries.d.ts.map