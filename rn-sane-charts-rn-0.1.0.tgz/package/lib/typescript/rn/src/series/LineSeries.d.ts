import type { Series } from '@rn-sane-charts/core';
import { type MarkerStyle } from './markerSymbol';
export type LineSeriesProps = {
    series: Series;
    color?: string;
    strokeWidth?: number;
    marker?: Omit<MarkerStyle, 'color'> & {
        color?: string;
    };
};
/**
 * Draw a single line series inside the plot region.
 *
 * Implementation note:
 * - The core package returns an SVG-style path string for determinism and easy testing.
 * - Skia can ingest that path string directly.
 */
export declare function LineSeries(props: LineSeriesProps): import("react/jsx-runtime").JSX.Element | null;
//# sourceMappingURL=LineSeries.d.ts.map