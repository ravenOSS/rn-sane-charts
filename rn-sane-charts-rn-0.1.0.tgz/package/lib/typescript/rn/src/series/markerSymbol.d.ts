export type MarkerSymbol = 'circle' | 'plus' | 'cross' | 'square' | 'diamond' | 'triangle';
export type MarkerStyle = {
    symbol?: MarkerSymbol;
    size?: number;
    color: string;
    opacity?: number;
    strokeWidth?: number;
    filled?: boolean;
};
type MarkerGlyphProps = MarkerStyle & {
    x: number;
    y: number;
};
/**
 * Draw a point marker glyph at chart coordinates.
 *
 * Why this helper exists:
 * - Keeps symbol rendering consistent across line/area/scatter series.
 * - Centralizes marker semantics so future symbols can be added once.
 *
 * Invariants:
 * - `size` is treated as full visual diameter/extent (not radius).
 * - Stroke-only symbols (`plus`, `cross`) ignore `filled`.
 */
export declare function MarkerGlyph(props: MarkerGlyphProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=markerSymbol.d.ts.map